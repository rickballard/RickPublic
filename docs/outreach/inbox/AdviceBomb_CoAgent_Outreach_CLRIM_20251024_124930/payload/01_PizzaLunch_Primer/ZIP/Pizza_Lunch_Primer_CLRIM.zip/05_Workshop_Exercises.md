Premortem, dot vote, RACI quick‑start.
