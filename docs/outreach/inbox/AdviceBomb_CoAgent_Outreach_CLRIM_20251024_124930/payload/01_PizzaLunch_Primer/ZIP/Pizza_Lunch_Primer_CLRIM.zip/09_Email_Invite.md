Invite with pro bono note.
