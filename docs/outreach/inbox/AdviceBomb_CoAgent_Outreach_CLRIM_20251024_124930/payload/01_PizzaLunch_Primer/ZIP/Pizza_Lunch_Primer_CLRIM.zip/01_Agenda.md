00:00 frame; 00:05 reality; 00:15 premortem; 00:35 options; 00:50 commit.
