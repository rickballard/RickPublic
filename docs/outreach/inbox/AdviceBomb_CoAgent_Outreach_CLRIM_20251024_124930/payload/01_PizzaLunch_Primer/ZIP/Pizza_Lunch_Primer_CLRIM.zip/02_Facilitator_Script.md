Mirror CLRIM language; emphasize boutique, BNN credibility, disciplined research.
