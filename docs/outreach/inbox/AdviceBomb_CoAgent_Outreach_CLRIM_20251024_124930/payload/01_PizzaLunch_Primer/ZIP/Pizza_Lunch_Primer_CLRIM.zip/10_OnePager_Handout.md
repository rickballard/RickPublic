Summary of why/what/how.
